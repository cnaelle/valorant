<?php
// Insert here your custom code to extend Kronos / WordPress API endpoints and behavior.
