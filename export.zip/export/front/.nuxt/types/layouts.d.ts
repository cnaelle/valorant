import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "account" | "default"
declare module "C:/Users/user/Desktop/code/front/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}