
import { defuFn } from 'C:/Users/user/Desktop/code/front/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
