import fr from '@kronos/core/i18n/fr'

export default {
  fr
}
